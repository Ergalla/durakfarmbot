
<h1 align="center">
  <br>
  <a href="https://github.com/Zakovskiy/durakonline.py"><img src="https://github.com/Zakovskiy/durakonline.py/blob/main/icon.png?raw=true" width="500"></a>
  <br>
  Durak Online API on Python
  <br>
</h1>

<p align="center">
  <a href="https://discord.gg/AsYzxRfT6J"><img src="https://bit.ly/32neyjM"></a>
</p>

# Install
```
git clone https://github.com/Zakovskiy/durakonline.py
```

# Import and Auth
```python
import durakonline

DurakOnline = durakonline.Client("access_token");
```

### [Telegram](https://t.me/zakovskiy)
