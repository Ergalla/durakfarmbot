# Access Token

The access token can be obtained by sniff traffic to the [HttpCanary](https://trashbox.ru/link/httpcanary-android) application (no root)

![](https://github.com/Zakovskiy/durakonline.py/blob/main/docs/accesstoken.jpg?raw=true)

---
